"""Suwayhib's engine in the browser (Pyodide, in worker.js): web/app's Session, fed by the
streaming Zipformer that runs in the same worker (sherpa-onnx, WebAssembly).

The worker passes each 100 ms of audio together with the phoneme units the model has just
emitted for it; the decoder picks them up through _Backend.accept. Replies are JSON strings
of the messages the web server would send over its WebSocket.
"""
import json
import os

os.environ.setdefault("SUWAYHIB_DATA", "/app/data")  # nothing is read from it: no reference audio here

import js  # noqa: E402  (the worker's globals: zfReset, zfDecode)
import numpy as np  # noqa: E402
from pyodide.ffi import to_js  # noqa: E402

import api  # noqa: E402
from session import Session  # noqa: E402
from zipformer_decoder import ZipformerDecoder  # noqa: E402


class _Backend:
    """zipformer_decoder's backend: the model already ran in JavaScript for this chunk."""

    def __init__(self):
        self.pending = []

    def reset(self):
        js.zfReset()  # a fresh stream
        self.pending = []

    def accept(self, chunk):
        out, self.pending = self.pending, []
        return out

    def decode(self, wave):
        return str(js.zfDecode(to_js(memoryview(np.asarray(wave, dtype=np.float32).tobytes()))))


class Engine:
    def __init__(self):
        self.backend = _Backend()
        self.decoder = ZipformerDecoder(self.backend)
        self.session = Session(self.decoder)

    def feed(self, chunk, units: str) -> str:
        """chunk: a Float32Array (16 kHz mono); units: JSON [[time_s, unit], ...] for it."""
        self.backend.pending = [tuple(u) for u in json.loads(units)]
        x = np.frombuffer(chunk.to_py(), dtype=np.float32).copy()
        return json.dumps(self.session.feed(x), ensure_ascii=False)

    def command(self, text: str) -> str:
        """A text message from the page ({"type": "reset" | "start_at" | "pace", ...})."""
        cmd = json.loads(text)
        kind = cmd.get("type")
        if kind == "pace":
            out = self.session.set_pace(cmd.get("pace"))
        elif kind == "start_at":
            out = self.session.start_at(int(cmd["sura"]), int(cmd["aya"]), int(cmd["word"]))
        elif kind == "reset":
            self.session.reset()
            self.decoder.reset()
            out = [{"type": "status", "text": "Ready. Start reciting anywhere."}]
        else:
            out = []
        return json.dumps(out, ensure_ascii=False)

    def request(self, path: str, query: str = "") -> str:
        """A data request from the page (/page/12, /verse/2/255, ...). Empty string = not found."""
        q = dict(p.split("=", 1) for p in query.split("&") if "=" in p) if query else {}
        try:
            return api.handle(path, q)
        except api.NotFound:
            return ""


def create() -> Engine:
    return Engine()
