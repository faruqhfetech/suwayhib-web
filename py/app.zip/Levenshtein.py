"""Pure-Python stand-in for the Levenshtein package (distance, ratio, editops, opcodes).

The C package (via rapidfuzz) has no Android build. quran_transcript's phonetizer uses
opcodes() to carry tajweed annotations through each text rewrite, so the alignment must
be the same one rapidfuzz picks, not just any minimal one. Like rapidfuzz, common prefix
and suffix are stripped first, then the edit matrix is walked back from the end; ties
are broken in rapidfuzz's order. android/tools/shim_check.py compares this with the real
package on every rewrite the phonetizer makes over the whole Qur'an.
"""

import numpy as np

ORDER = "rapidfuzz"  # how ties are broken while walking back (checked by shim_check)
SMALL = 400  # below this many cells the plain loop is faster than numpy


def _codes(s):
    return np.frombuffer(s.encode("utf-32-le"), dtype=np.uint32)


def _rows(a, b):
    """The edit matrix's rows, each computed at once with numpy. Same values as the cell
    by cell recurrence: substitution and deletion come from the row above; insertions
    along the row are a running minimum (row[j] = min(row[j], row[j-1] + 1))."""
    m = len(b)
    bc = _codes(b)
    ar = np.arange(m + 1, dtype=np.int32)
    prev = ar.copy()
    yield prev
    for i, ch in enumerate(_codes(a), 1):
        row = np.empty(m + 1, dtype=np.int32)
        row[0] = i
        np.minimum(prev[1:] + 1, prev[:-1] + (bc != ch), out=row[1:])
        row = np.minimum.accumulate(row - ar) + ar
        yield row
        prev = row


def _matrix(a, b):
    n, m = len(a), len(b)
    if n * m >= SMALL:
        return np.array(list(_rows(a, b))).tolist()
    d = [list(range(m + 1))]
    for i in range(1, n + 1):
        prev = d[-1]
        row = [i] + [0] * m
        ai = a[i - 1]
        for j in range(1, m + 1):
            row[j] = min(prev[j] + 1, row[j - 1] + 1, prev[j - 1] + (ai != b[j - 1]))
        d.append(row)
    return d


def distance(a, b):
    if a == b:
        return 0
    if len(a) * len(b) >= SMALL:
        for row in _rows(a, b):
            pass
        return int(row[-1])
    prev = list(range(len(b) + 1))
    for i, ai in enumerate(a, 1):
        row = [i]
        for j, bj in enumerate(b, 1):
            row.append(min(prev[j] + 1, row[j - 1] + 1, prev[j - 1] + (ai != bj)))
        prev = row
    return prev[-1]


def ratio(a, b):
    total = len(a) + len(b)
    if total == 0:
        return 1.0
    # indel-based normalised similarity, as Levenshtein.ratio
    n, m = len(a), len(b)
    prev = [0] * (m + 1)
    for i in range(1, n + 1):
        row = [0] * (m + 1)
        for j in range(1, m + 1):
            row[j] = prev[j - 1] + 1 if a[i - 1] == b[j - 1] else max(prev[j], row[j - 1])
        prev = row
    return 2 * prev[m] / total


def editops(a, b, order=ORDER):
    """[(tag, i, j)] with tag in replace / insert / delete, as Levenshtein.editops."""
    pre = 0
    while pre < len(a) and pre < len(b) and a[pre] == b[pre]:
        pre += 1
    suf = 0
    while suf < len(a) - pre and suf < len(b) - pre and a[-1 - suf] == b[-1 - suf]:
        suf += 1
    sa, sb = a[pre:len(a) - suf], b[pre:len(b) - suf]
    d = _matrix(sa, sb)
    i, j = len(sa), len(sb)
    ops = []
    if order == "rapidfuzz":
        # rapidfuzz's recover_alignment, written on the plain matrix:
        # deletion when the cell is one more than the one above it; otherwise step back in
        # b, and it is an insertion when that row drops by one at i; else a match/replace
        while i and j:
            if d[i][j] == d[i - 1][j] + 1:
                ops.append(("delete", i - 1 + pre, j + pre))
                i -= 1
                continue
            j -= 1
            if j and d[i][j] - d[i - 1][j] == -1:
                ops.append(("insert", i + pre, j + pre))
            else:
                i -= 1
                if sa[i] != sb[j]:
                    ops.append(("replace", i + pre, j + pre))
        while i:
            i -= 1
            ops.append(("delete", i + pre, j + pre))
        while j:
            j -= 1
            ops.append(("insert", i + pre, j + pre))
        ops.reverse()
        return ops
    while i or j:
        cur = d[i][j]
        for step in order:
            if step == "diag" and i and j and d[i - 1][j - 1] + (sa[i - 1] != sb[j - 1]) == cur:
                if sa[i - 1] != sb[j - 1]:
                    ops.append(("replace", i - 1 + pre, j - 1 + pre))
                i, j = i - 1, j - 1
                break
            if step == "delete" and i and d[i - 1][j] + 1 == cur:
                ops.append(("delete", i - 1 + pre, j + pre))
                i -= 1
                break
            if step == "insert" and j and d[i][j - 1] + 1 == cur:
                ops.append(("insert", i + pre, j - 1 + pre))
                j -= 1
                break
    ops.reverse()
    return ops


def opcodes(a, b, order=ORDER):
    """[(tag, i1, i2, j1, j2)] covering both strings, as Levenshtein.opcodes."""
    out = []
    i = j = 0
    for tag, ei, ej in editops(a, b, order):
        if i < ei or j < ej:
            # an equal run first (both sides advance together)
            k = min(ei - i, ej - j)
            if k > 0:
                out.append(("equal", i, i + k, j, j + k))
                i += k
                j += k
        if tag == "replace":
            out.append(("replace", ei, ei + 1, ej, ej + 1))
            i, j = ei + 1, ej + 1
        elif tag == "delete":
            out.append(("delete", ei, ei + 1, ej, ej))
            i, j = ei + 1, ej
        else:
            out.append(("insert", ei, ei, ej, ej + 1))
            i, j = ei, ej + 1
    if i < len(a) or j < len(b):
        out.append(("equal", i, len(a), j, len(b)))
    # merge neighbours with the same tag, as the C version does
    merged = []
    for op in out:
        if merged and merged[-1][0] == op[0] and merged[-1][2] == op[1] and merged[-1][4] == op[3]:
            p = merged[-1]
            merged[-1] = (p[0], p[1], op[2], p[3], op[4])
        else:
            merged.append(op)
    return merged
