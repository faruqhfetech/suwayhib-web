"""The streaming Zipformer behind the call the tracker makes to Muaalem.

The model (Quran-Lab zipformer_p-arabic-v3.1, cache-aware streaming CTC, 65.5M parameters)
hears the live stream once, in order, and emits phoneme units with their times. It writes
the same quran-transcript phonetic script as Muaalem, so the tracker's alignment works
unchanged. Used by the web server and by the Android app.

The tracker asks for "the phonemes of this audio window". Its windows are slices of the
recent stream (its audio buffer ends where the stream ends, apart from being cut at a
pause), so a window is located in the stream by matching samples and answered with the
units stamped inside it. The newest ~LAG seconds have no units yet; a full-length window
is slid back to end there, never across a pause.

backend: an object with
    accept(chunk float32) -> list of (time_s, unit) newly emitted, times from stream start
    reset()               -> start a new stream
    decode(wave)          -> phoneme string of a standalone wave (not part of the stream)
SherpaBackend below is the one for a computer (sherpa-onnx's Python package); the
Android app passes its own (Zipformer.kt).
"""
import os
from dataclasses import dataclass
from pathlib import Path

import numpy as np

SR = 16000
KEEP = 30.0           # seconds of stream (and units) remembered
PAUSE = 0.25          # silence this long splits the stream into segments
SILENCE_RATIO = 0.08  # a chunk is silent below this fraction of the recent speech level
LAG = 0.8  # seconds behind the stream end before units are final (measured: at most 0.72 s)
# A unit is time-stamped late: a held madd is one unit, stamped where the vowel ends, and a
# verse's last consonant lands 0.1-0.33 s after the speech stops (measured on 7 verses),
# outside the tracker's window, which ends with the speech. Units are moved back by this
# (without it: 29 false flags in the streaming regression; with it: 6).
SHIFT = 0.35
# the window lengths the tracker and the locator ask for (tracker.VerseTracker.window,
# session.LOCATE_MAX_SEC); only these may slide back
FULL_WINDOWS = (4.0, 8.0)
# debugging: SUWAYHIB_TRACE="from,to" (stream seconds) prints every window asked for
_TRACE = tuple(float(v) for v in os.environ["SUWAYHIB_TRACE"].split(",")) if os.environ.get("SUWAYHIB_TRACE") else None

MODEL = Path(os.environ.get("SUWAYHIB_ZIPFORMER", Path.home() / "alt_models" / "zipformer_p-arabic-v3"
                            / "zipformer_p_arabic_v3.1.int8.onnx"))


@dataclass
class _Phonemes:
    text: str


@dataclass
class _Out:
    phonemes: _Phonemes


class ZipformerDecoder:
    """Muaalem-compatible callable over a live stream."""

    streaming = True  # answers improve as later units arrive: the tracker must not cache them

    def __init__(self, backend, lag=LAG):
        self.backend = backend
        self.lag = int(lag * SR)
        self.hop, self.ahead = self.lag, 0  # the decoder's delay, for the session's "lost" allowance
        self.full_windows = tuple(int(w * SR) for w in FULL_WINDOWS)
        self.reset()

    def reset(self):
        self.backend.reset()
        self.stream = np.zeros(0, dtype=np.float32)
        self.base = 0          # absolute sample index of stream[0]
        self.done = 0          # absolute sample up to which units are final
        self.units = []        # (absolute sample, unit)
        self.decode_s = 0.0    # audio seconds heard (for the cost figure)
        self.level = 0.0       # recent speech level
        self.silent = 0        # samples of silence in a row
        self.seg_start = 0     # absolute sample where speech last resumed after a pause

    @property
    def end(self):
        return self.base + len(self.stream)

    def push(self, chunk):
        chunk = np.asarray(chunk, dtype=np.float32)
        start = self.end
        self.stream = np.concatenate([self.stream, chunk])
        for t, u in self.backend.accept(chunk):
            self.units.append((int((t - SHIFT) * SR), u))
        self.decode_s += len(chunk) / SR
        rms = float(np.sqrt(np.mean(chunk ** 2))) if len(chunk) else 0.0
        self.level = max(self.level * 0.995, rms)
        if rms < SILENCE_RATIO * self.level:
            self.silent += len(chunk)
        else:
            if self.silent >= PAUSE * SR:
                self.seg_start = start
            self.silent = 0
        # final up to LAG behind the end; in a pause, everything before the silence is final
        self.done = max(self.done, self.end - self.lag)
        if self.silent >= self.lag:
            self.done = self.end
        excess = len(self.stream) - int(KEEP * SR)
        if excess > 0:
            self.stream = self.stream[excess:]
            self.base += excess
            self.units = [x for x in self.units if x[0] >= self.base]

    def flush(self):
        """The learner stopped: let the last units out."""
        self.push(np.zeros(self.lag, dtype=np.float32))
        self.done = self.end

    def text(self, a, b):
        return "".join(u for s, u in self.units if a <= s < b)

    def locate(self, x):
        """Absolute [start, end) of window x in the stream, or None."""
        n = len(x)
        if n == 0 or n > len(self.stream):
            return None
        tail = x[-min(n, 320):]
        # the window ends at the stream end, or at an earlier pause (a chunk boundary). A
        # quick check on its last samples, then the whole window: a silent tail (digital
        # zeros, as at the end of a recording) matches every later silence too
        for back in range(0, len(self.stream) - n + 1, 160):
            e = len(self.stream) - back
            if np.array_equal(self.stream[e - len(tail):e], tail) and np.array_equal(self.stream[e - n:e], x):
                return self.base + e - n, self.base + e
        return None

    # --- the call the tracker and session make to Muaalem ---------------------------
    def __call__(self, waves, refs=None, sampling_rate=SR):
        out = []
        for x in waves:
            x = np.asarray(x, dtype=np.float32)
            span = self.locate(x)
            if span is None:  # not from the stream (e.g. a test): decode it on its own
                out.append(_Out(_Phonemes(self.backend.decode(x))))
                continue
            a, b = span
            if b > self.done:  # not final that far yet
                if any(abs((b - a) - w) <= 160 for w in self.full_windows):
                    # a full-length window: slide it back to end where units are final,
                    # but never across a pause
                    a = max(a - (b - self.done), min(a, self.seg_start))
                # a shorter window was cut on purpose (a pause, or where this verse's
                # audio began): keep its start, so it never sees the previous verse
                b = self.done
            out.append(_Out(_Phonemes(self.text(a, b))))
            if _TRACE and _TRACE[0] <= self.end / SR <= _TRACE[1]:
                print(f"    t={self.end / SR:6.2f} done={self.done / SR:6.2f} quiet={self.silent / SR:4.2f}s "
                      f"window {span[0] / SR:6.2f}-{span[1] / SR:6.2f} -> {a / SR:6.2f}-{b / SR:6.2f}  ...{self.text(a, b)[-16:]}")
        return out


class SherpaBackend:
    """The model on a computer: sherpa-onnx's Python package (pip install sherpa-onnx).
    The model is gated on Hugging Face (Quran-Lab/zipformer_p-arabic-v3); point
    SUWAYHIB_ZIPFORMER at its int8 .onnx, with tokens.txt beside it."""

    def __init__(self, path=MODEL, threads=1, recognizer=None):
        """recognizer: an existing one to share (one model in memory, a stream per user)."""
        self.rec = recognizer or self.recognizer(path, threads)
        self.reset()

    @staticmethod
    def recognizer(path=MODEL, threads=1):
        import sherpa_onnx
        return sherpa_onnx.OnlineRecognizer.from_zipformer2_ctc(
            tokens=str(Path(path).parent / "tokens.txt"), model=str(path), num_threads=threads,
            sample_rate=SR, feature_dim=80, decoding_method="greedy_search")

    def reset(self):
        self.st, self.n = self.rec.create_stream(), 0

    def _drain(self, st):
        while self.rec.is_ready(st):
            self.rec.decode_stream(st)

    def accept(self, chunk):
        self.st.accept_waveform(SR, chunk)
        self._drain(self.st)
        r = self.rec.get_result_all(self.st)
        new = list(zip(r.timestamps[self.n:], r.tokens[self.n:]))
        self.n = len(r.tokens)
        return new

    def decode(self, wave):
        st = self.rec.create_stream()
        st.accept_waveform(SR, np.asarray(wave, dtype=np.float32))
        st.input_finished()
        self._drain(st)
        return "".join(self.rec.get_result_all(st).tokens)
