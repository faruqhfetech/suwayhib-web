"""Madani mushaf (604 pages) verse -> page map, from Tanzil quran-data.js (QuranData.Page)."""
import bisect
import re
from functools import lru_cache
from pathlib import Path

from quran_transcript import Aya

DATA = Path(__file__).resolve().parent / "quran-data.js"

# ayah counts per sura, for walking to the next verse
AYAT = [7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
        112, 78, 118, 64, 77, 227, 93, 88, 69, 60, 34, 30, 73, 54, 45, 83, 182, 88, 75, 85, 54, 53,
        89, 59, 37, 35, 38, 29, 18, 45, 60, 49, 62, 55, 78, 96, 29, 22, 24, 13, 14, 11, 11, 18, 12,
        12, 30, 52, 52, 44, 28, 28, 20, 56, 40, 31, 50, 40, 46, 42, 29, 19, 36, 25, 22, 17, 19, 26,
        30, 20, 15, 21, 11, 8, 8, 19, 5, 8, 8, 11, 11, 8, 3, 9, 5, 4, 7, 3, 6, 3, 5, 4, 5, 6]


# common English transliterations, for searching the surah list
NAMES_EN = ['Al-Fatihah', 'Al-Baqarah', 'Aal-Imran', 'An-Nisa', 'Al-Maidah', 'Al-Anam', 'Al-Araf', 'Al-Anfal', 'At-Tawbah', 'Yunus', 'Hud', 'Yusuf', 'Ar-Rad', 'Ibrahim', 'Al-Hijr', 'An-Nahl', 'Al-Isra', 'Al-Kahf', 'Maryam', 'Ta-Ha', 'Al-Anbiya', 'Al-Hajj', 'Al-Muminun', 'An-Nur', 'Al-Furqan', 'Ash-Shuara', 'An-Naml', 'Al-Qasas', 'Al-Ankabut', 'Ar-Rum', 'Luqman', 'As-Sajdah', 'Al-Ahzab', 'Saba', 'Fatir', 'Ya-Sin', 'As-Saffat', 'Sad', 'Az-Zumar', 'Ghafir', 'Fussilat', 'Ash-Shura', 'Az-Zukhruf', 'Ad-Dukhan', 'Al-Jathiyah', 'Al-Ahqaf', 'Muhammad', 'Al-Fath', 'Al-Hujurat', 'Qaf', 'Adh-Dhariyat', 'At-Tur', 'An-Najm', 'Al-Qamar', 'Ar-Rahman', 'Al-Waqiah', 'Al-Hadid', 'Al-Mujadilah', 'Al-Hashr', 'Al-Mumtahanah', 'As-Saff', 'Al-Jumuah', 'Al-Munafiqun', 'At-Taghabun', 'At-Talaq', 'At-Tahrim', 'Al-Mulk', 'Al-Qalam', 'Al-Haqqah', 'Al-Maarij', 'Nuh', 'Al-Jinn', 'Al-Muzzammil', 'Al-Muddaththir', 'Al-Qiyamah', 'Al-Insan', 'Al-Mursalat', 'An-Naba', 'An-Naziat', 'Abasa', 'At-Takwir', 'Al-Infitar', 'Al-Mutaffifin', 'Al-Inshiqaq', 'Al-Buruj', 'At-Tariq', 'Al-Ala', 'Al-Ghashiyah', 'Al-Fajr', 'Al-Balad', 'Ash-Shams', 'Al-Layl', 'Ad-Duha', 'Ash-Sharh', 'At-Tin', 'Al-Alaq', 'Al-Qadr', 'Al-Bayyinah', 'Az-Zalzalah', 'Al-Adiyat', 'Al-Qariah', 'At-Takathur', 'Al-Asr', 'Al-Humazah', 'Al-Fil', 'Quraysh', 'Al-Maun', 'Al-Kawthar', 'Al-Kafirun', 'An-Nasr', 'Al-Masad', 'Al-Ikhlas', 'Al-Falaq', 'An-Nas']


@lru_cache(maxsize=1)
def _starts():
    src = DATA.read_text(encoding="utf-8")
    block = src[src.index("QuranData.Page"):]
    block = block[:block.index("];") + 1]
    pairs = [tuple(map(int, m)) for m in re.findall(r"\[(\d+),\s*(\d+)\]", block)]
    return pairs  # pairs[i] = first (sura, aya) of page i+1; last entry is a sentinel


@lru_cache(maxsize=1)
def juz_starts():
    """First (sura, aya) of each of the 30 juz, from Tanzil's QuranData.Juz."""
    src = DATA.read_text(encoding="utf-8")
    block = src[src.index("QuranData.Juz"):]
    block = block[:block.index("];") + 1]
    return [tuple(map(int, m)) for m in re.findall(r"\[(\d+),\s*(\d+)\]", block)][:30]


def page_of(sura: int, aya: int) -> int:
    starts = _starts()
    return max(1, bisect.bisect_right(starts, (sura, aya)))


def next_verse(sura: int, aya: int):
    if aya < AYAT[sura - 1]:
        return sura, aya + 1
    return (sura + 1, 1) if sura < 114 else None


@lru_cache(maxsize=64)
def page_content(page: int) -> dict:
    """All verses on a page, with their uthmani words, for the interface."""
    starts = _starts()
    s, a = starts[page - 1]
    end = starts[page] if page < len(starts) else (115, 1)
    verses = []
    while (s, a) < end:
        v = Aya(s, a).get()
        item = {"sura": s, "aya": a, "sura_name": v.sura_name, "words": v.uthmani_words}
        if a == 1 and s not in (1, 9) and v.bismillah_uthmani:
            item["basmala"] = v.bismillah_uthmani.split()  # its own line, as in a printed mushaf
        verses.append(item)
        nxt = next_verse(s, a)
        if nxt is None:
            break
        s, a = nxt
    return {"page": page, "verses": verses}

