"""Streaming follow-along tracker for one verse.

Audio arrives in small chunks. Every `hop` seconds the last `window` seconds are decoded
with Muaalem, and the decoded phonemes are fitted into the expected verse's phonemes
(overlap alignment: the window may start and end anywhere in the verse). The end of the
fit says how far the learner has got. A word is judged once the learner has clearly
moved past it, while it still sits wholly inside the window; it is flagged when too
much of it was wrong or missing.

Going back is not a mistake. A pause (silence) splits the recording into segments and
the window never spans one. The first look after a pause searches the whole verse, so
a learner who resumes from the last word, the middle or the verse start is followed
there and re-checked from that point. A word said again straight away with no pause is
noted as a soft "repeat" event and never stops the learner.

Stopping and starting change pronunciation (waqf / ibtida): the word before a pause
loses its final vowel or merged sound, and the word after it may gain a pronounced
hamzat al-wasl. So the reference is the verse phonetized in pieces, split at every
written word where the learner actually stopped or restarted.
"""
import hashlib
from dataclasses import dataclass, field

import numpy as np
from common import Aya

from common import DEFAULT_STYLE, SR, STYLES, phonetize

PREFIX_CUT = 4         # phonemes of a window's left edge that may be discarded cheaply
LOOKAHEAD_WORDS = 12   # how far past the current word the fit may land
MIN_PHONEMES = 6       # don't judge from a window with fewer decoded phonemes
MAX_FIT_COST = 0.6     # don't judge when the fit costs more than this per decoded phoneme
MIN_REPEAT_PHONEMES = 4  # shorter words doubled are too easy to hit by chance
PAUSE_SEC = 0.35       # silence this long starts a new segment (the learner may go back)
SILENCE_RATIO = 0.08   # chunk is silent below this fraction of the recent speech level
POSITION_BIAS = 0.01   # after a pause, per-phoneme preference for fits near the current word
BACK_MARGIN = 2.0      # going back needs a fit this much cheaper than carrying on
SPILL_MIN = 3          # decoded phonemes past the verse end that mean "already into the next verse"
SLIGHT_MIN = 2         # tajweed detail off by this many units (counts) marks a word amber
AHEAD_BIAS = 0.3       # per phoneme: cost of the fit starting past the current word (carry on bias)
MIN_VISIBLE = 0.66     # judge a word only if at least this share of it is inside the window
SETTLE_SEC = 1.0       # this much quiet settles what was said, even if no more speech follows
SHORT_STOP_SEC = 0.1   # a stop on a word (waqf) has at least this much quiet (one silent 0.1 s chunk), even when too
                       # short to count as a pause; a word whose end is merely cut off has none
import re as _re
VARIABLE_MADD = _re.compile("ا{3,}|ۦ{3,}|ۥ{3,}")  # a madd longer than natural: its length depends on pace

_DECODE_CACHE: dict = {}  # audio window hash -> decoded phonemes (shared across trackers)


def fit(dec: str, ref: str, prefer: int | None = None, lam: float = 0.0, anchor_end: bool = False,
        ahead_of: int | None = None, ahead_lam: float = 0.0):
    """Overlap alignment of `dec` (decoded window) inside `ref` (verse phonemes).

    Free to start anywhere in ref and to drop a short garbled prefix of dec (the window's
    left edge cuts a word). Returns (ref_start, ref_end, per-ref-char cost array,
    total cost) for the best fit ending anywhere in ref. With `prefer`, ties between
    equally good places (a verse repeating its own phrase) go to the one ending closest
    to `prefer`: each phoneme of distance adds `lam`. With `anchor_end`, the fit must end
    exactly at the end of ref (the learner stopped there). With `ahead_of`, starting the fit
    beyond that ref position costs `ahead_lam` per phoneme skipped: learners carry on from
    where they are, so a phrase repeated later in the verse must not pull the fit forward.
    """
    n, m = len(dec), len(ref)
    D = np.zeros((n + 1, m + 1), dtype=np.float32)
    if ahead_of is not None and m:
        D[0, :] = ahead_lam * np.maximum(0, np.arange(m + 1) - ahead_of)
    # cheap to discard a short cut-off prefix of the window (a word sliced by the left
    # edge), full price beyond that so a repeated word cannot be thrown away for free
    cut = min(n, PREFIX_CUT)
    D[1:cut + 1, 0] = np.arange(1, cut + 1) * 0.5
    D[cut + 1:, 0] = cut * 0.5 + np.arange(1, n - cut + 1)
    B = np.zeros((n + 1, m + 1), dtype=np.int8)  # 0 diag, 1 up (extra dec), 2 left (missing ref)
    refa = np.array(list(ref)) if m else np.array([], dtype="<U1")
    jj = np.arange(m + 1, dtype=np.float32)
    for i in range(1, n + 1):
        # sub/ins don't depend on this row; dele (from the left) is a running minimum
        sub = D[i - 1, :-1] + (refa != dec[i - 1])
        ins = D[i - 1, 1:] + 1.0
        best = np.minimum(sub, ins)
        bp = np.where(sub <= ins, 0, 1).astype(np.int8)
        row = np.concatenate([[D[i, 0]], best])
        # D[i, j] = min(best_j, D[i, j-1] + 1)  ==  j + cummin(best_k - k)
        run = np.minimum.accumulate(row - jj) + jj
        D[i] = run
        B[i, 1:] = np.where(run[1:] < row[1:], 2, bp)
    last = D[n, 1:].copy()
    if prefer is not None and m:
        last += lam * np.abs(np.arange(1, m + 1) - prefer)
    end = m if anchor_end else (int(np.argmin(last)) + 1 if m else 0)
    cost = np.zeros(m, dtype=np.float32)
    # P[k]: where, in dec, the alignment stands after the first k ref chars, so the decoded
    # sounds for ref chars lo..b-1 are dec[P[lo]:P[b]] (beyond the fit: n; before it: its start)
    P = np.full(m + 1, n, dtype=np.int32)
    i, j = n, end
    P[j] = i
    while i > 0 and j > 0:
        b = B[i, j]
        if b == 0:
            cost[j - 1] += 0.0 if dec[i - 1] == ref[j - 1] else 1.0
            i, j = i - 1, j - 1
        elif b == 1:
            cost[min(j, m - 1)] += 1.0  # extra decoded phoneme, charged to the next ref char
            i -= 1
        else:
            cost[j - 1] += 1.0
            j -= 1
        P[j] = min(P[j], i)
    P[:j] = i
    fit.last_P = P  # read straight after the call (single-threaded tracker)
    return j, end, cost, float(D[n, end])


# --- clear error (red, lahn jali) vs tajweed detail (amber, lahn khafi) ---------------
MADD = set("اۦۥ")                  # long vowels: a run is the madd length in counts
GHUNNA = set("نمں۾")               # nasal: run length is the ghunna length
KHAFI = set("ڇں۪ۜـٲؙ۾")           # qalqala, ikhfa noon/meem, sakt, imala, tas-hil, ikhtilas
NASAL_PAIRS = {frozenset("نں"), frozenset("م۾"), frozenset("ب۾")}  # ikhfa/iqlab applied or not


def _rle(s: str):
    out = []
    for ch in s:
        if out and out[-1][0] == ch:
            out[-1][1] += 1
        else:
            out.append([ch, 1])
    return out


def classify(ref_seg: str, dec_seg: str):
    """Compare one word's expected and heard phonemes by runs (a run's length is a madd,
    ghunna or shadda). Returns (severe, slight):
      severe: clear errors, in letters: a wrong/missing/extra letter or short vowel, a long
              vowel reduced to short (or the reverse), a shadda missing or added.
      slight: tajweed detail, in counts: a madd or ghunna still there but the wrong length,
              qalqala / ikhfa / iqlab / imala / tas-hil / sakt missed or added."""
    R, H = _rle(ref_seg), _rle(dec_seg)
    nr, nh = len(R), len(H)
    D = np.zeros((nr + 1, nh + 1), dtype=np.int32)
    D[:, 0] = np.arange(nr + 1)
    D[0, :] = np.arange(nh + 1)
    for x in range(1, nr + 1):
        for y in range(1, nh + 1):
            D[x, y] = min(D[x - 1, y - 1] + (R[x - 1][0] != H[y - 1][0]), D[x - 1, y] + 1, D[x, y - 1] + 1)
    severe = slight = 0
    x, y = nr, nh
    while x > 0 or y > 0:
        if x > 0 and y > 0 and D[x, y] == D[x - 1, y - 1] + (R[x - 1][0] != H[y - 1][0]):
            (cr, kr), (ch, kh) = R[x - 1], H[y - 1]
            if cr == ch:
                long_r, long_h = kr >= 2, kh >= 2
                if cr in MADD:
                    if long_r and long_h:
                        slight += abs(kr - kh)          # madd length off
                    elif long_r != long_h:
                        severe += 1                     # long vowel made short (maal -> mal)
                elif long_r != long_h:
                    severe += 1                         # shadda missing or added
                elif cr in GHUNNA and long_r:
                    slight += abs(kr - kh)              # ghunna length off
            elif frozenset((cr, ch)) in NASAL_PAIRS or (cr in KHAFI and ch in KHAFI):
                slight += max(kr, kh)                   # ikhfa/iqlab not applied, etc.
            else:
                severe += kr                            # different letter or vowel
            x, y = x - 1, y - 1
        elif x > 0 and (y == 0 or D[x, y] == D[x - 1, y] + 1):
            cr, kr = R[x - 1]
            if cr in KHAFI:
                slight += kr
            else:
                severe += kr                            # missing letter/vowel (or whole madd)
            x -= 1
        else:
            ch, kh = H[y - 1]
            if ch in KHAFI:
                slight += kh
            else:
                severe += kh                            # extra letter/vowel
            y -= 1
    return severe, slight


def fit_spill(dec: str, ref: str, tail: float = 0.3, **kw):
    """Like `fit`, but the decoded window may run on past the end of ref (the learner has
    gone on into the next verse): ending at ref's end and dropping the rest of dec costs
    `tail` per phoneme. Returns (start, end, cost, total, spill) where spill is how many
    decoded phonemes ran past the end; spill 0 means the ordinary fit was better."""
    s, e, c, tot = fit(dec, ref, **kw)
    best, bestP = (s, e, c, tot, 0), fit.last_P
    n, m = len(dec), len(ref)
    for i in range(max(1, n - 40), n):  # try handing the last few phonemes to the next verse
        s2, e2, c2, t2 = fit(dec[:i], ref, anchor_end=True, **kw)
        t2 += tail * (n - i)
        if t2 < best[3]:
            best, bestP = (s2, e2, c2, t2, n - i), fit.last_P
    fit.last_P = bestP
    return best


@dataclass
class Event:
    kind: str          # "ok", "slight" (tajweed detail), "error" (clear error), "back", "repeat", "done"
    word: int          # phoneme-word index in the reference at that moment
    text: str = ""
    err: float = 0.0
    t: float = 0.0     # audio time when emitted
    wword: int = -1    # written (uthmani) word index, for the interface
    style: str = ""    # the pace (hadr/tadwir/tahqiq) the word matched best
    slight: int = 0    # tajweed-detail units off


@dataclass
class VerseTracker:
    # phonemes needed before the first look after a pause may send the learner back. A
    # short fragment ("...mmin") can fit an earlier word as well as the current one; the
    # phone's streaming decoder sees less of a fresh stretch at first, so it raises this.
    first_look_min = MIN_PHONEMES

    muaalem: object
    sura: int
    aya: int
    window: float = 4.0
    hop: float = 0.5
    threshold: float = 0.15   # clear-error share of a word's phonemes to mark it red
    margin: int = 2           # phonemes into the next word before judging the previous one
    start_word: int = 0       # written word to start from (located mid-verse, or a repeat)
    resync: bool = False      # first fit may land ahead too: jump there without flagging skips
    # an optional lead-in before verse 1 (isti'adha, basmala): followed and judged when said,
    # silently skipped when the learner goes straight into the verse
    prefix: list = field(default_factory=list)
    pace: str | None = None   # None: any valid pace; or "hadr" / "tadwir" / "tahqiq" to practise one
    words: list = field(init=False)
    wmap: list = field(init=False)      # written word index of each phoneme word
    bounds: list = field(init=False)
    ref: str = field(init=False)
    audio: np.ndarray = field(init=False)
    next_word: int = field(init=False, default=0)
    _since: int = field(init=False, default=0)
    _seg_start: int = field(init=False, default=0)     # sample where the current segment began
    _seg_fresh: bool = field(init=False, default=False)  # no judgment yet since a pause
    _level: float = field(init=False, default=0.0)
    _silent_run: int = field(init=False, default=0)
    _pause_at: int = field(init=False, default=0)
    _short_stops: list = field(init=False, default_factory=list)  # audio positions where a short stop ended
    _spoke: bool = field(init=False, default=False)
    _settled: bool = field(init=False, default=False)  # the current pause was already settled
    spill: int = field(init=False, default=0)
    _pending_red: int | None = field(init=False, default=None)  # word that looked red once, to confirm

    def __post_init__(self):
        aya = Aya(self.sura, self.aya).get()
        self.optional_n = len(self.prefix)  # written words 0..optional_n-1 are the optional lead-in
        self.uw = list(self.prefix) + aya.uthmani_words
        self._ref_out = phonetize(aya.uthmani)  # Muaalem wants a reference object; decoding ignores it
        self._cache = {}
        self.cuts = [0]  # written word indices where a piece (a fresh start) begins
        # a start mid-verse uses that word's start form; so does the verse itself after an
        # optional lead-in (skipping the basmala, or stopping after it, is a fresh start: hamzat
        # al-wasl is pronounced, e.g. 18:1 "al-hamdu")
        self._set_cuts([0, self.start_word] + ([self.optional_n] if self.optional_n else []))
        self.next_word = self._first_word_of(self.start_word)
        self._seg_fresh = self.start_word > 0 or self.resync  # may still go back (or resync)
        self.audio = np.zeros(0, dtype=np.float32)

    # --- reference built from pieces ------------------------------------------------
    def _piece(self, c: int, d: int, style: str = DEFAULT_STYLE):
        """Phoneme words of written words c..d-1 recited as one stretch (start form at c,
        stop form at d-1), and the written index of each. A phoneme word that merges two
        written words maps to the first."""
        key = (c, d, style)
        if key not in self._cache:
            if style != DEFAULT_STYLE:
                # other paces only change madd lengths, never the word split
                words = phonetize(" ".join(self.uw[c:d]), remove_spaces=False, style=style).phonemes.split(" ")
                self._cache[key] = (words, self._piece(c, d)[1])
                return self._cache[key]
            words = phonetize(" ".join(self.uw[c:d]), remove_spaces=False).phonemes.split(" ")
            self._cache[key] = (words, self._word_map(c, d, len(words)))
        return self._cache[key]

    def _word_map(self, c: int, d: int, n_words: int) -> list[int]:
        """Written index of each of the n_words phoneme words of written words c..d-1.

        The reading merges a few written words into the one before (merged[i]: written
        word c+i adds no phoneme word). merges(j), the number of merges among c..j-1, only
        grows with j, so each merge is found by a binary search over prefixes: a few
        phonetizer runs per merge instead of one per word (the phonetizer is slow)."""
        if n_words == d - c:
            return list(range(c, d))
        if n_words > d - c:
            # a written word read as several (the opening letters, e.g. 19:1): the prefix count
            counts = [len(phonetize(" ".join(self.uw[c:j]), remove_spaces=False).phonemes.split(" "))
                      for j in range(c + 1, d + 1)]
            return [c + next(k for k, n in enumerate(counts) if n > q) for q in range(n_words)]
        seen = {}

        def merges(j):  # merges among written words c..j-1
            if j not in seen:
                seen[j] = (j - c) - len(phonetize(" ".join(self.uw[c:j]), remove_spaces=False).phonemes.split(" "))
            return seen[j]

        merged = [False] * (d - c)
        lo = c + 1
        for k in range(1, (d - c) - n_words + 1):
            hi = d
            while lo < hi:  # the first j with merges(j) >= k
                mid = (lo + hi) // 2
                if merges(mid) >= k:
                    hi = mid
                else:
                    lo = mid + 1
            merged[lo - 1 - c] = True
        return [c + i for i in range(d - c) if not merged[i]]

    def _build(self, cuts, stop=None, style: str = DEFAULT_STYLE):
        """Phoneme words for written words 0..stop-1 (default: the whole verse) with a
        fresh start at every cut."""
        stop = len(self.uw) if stop is None else stop
        edges = [c for c in cuts if c < stop] + [stop]
        words, wmap = [], []
        for c, d in zip(edges, edges[1:]):
            w, m = self._piece(c, d, style)
            words += w
            wmap += m
        return words, wmap

    def _set_cuts(self, cuts):
        """Rebuild the reference with fresh starts at `cuts`, keeping the pointer on the
        same written word."""
        keep = self.wmap[self.next_word] if getattr(self, "wmap", None) and self.next_word < len(self.wmap) else None
        self._pending_red = None  # word indices change: a half-confirmed red no longer applies
        self.cuts = sorted(set([0] + list(cuts)))
        self.words, self.wmap = self._build(self.cuts)
        self.ref = "".join(self.words)
        self.bounds, k = [], 0
        for w in self.words:
            self.bounds.append((k, k + len(w)))
            k += len(w)
        if keep is not None:
            self.next_word = self._first_word_of(keep)

    def written_span(self, q: int) -> list[int]:
        """Written words covered by phoneme word q (two when the reading merges them)."""
        if q >= len(self.wmap):
            return []
        nxt = self.wmap[q + 1] if q + 1 < len(self.wmap) else len(self.uw)
        return list(range(self.wmap[q], max(nxt, self.wmap[q] + 1)))

    def _first_word_of(self, written: int) -> int:
        return next((q for q, w in enumerate(self.wmap) if w >= written), len(self.words))

    # --- audio --------------------------------------------------------------------
    def _decode(self, upto: int | None = None) -> str:
        hi = len(self.audio) if upto is None else upto
        lo = max(self._seg_start, hi - int(self.window * SR))  # never look back across a pause
        x = self.audio[lo:hi]
        if len(x) < int(0.3 * SR):
            return ""
        if getattr(self.muaalem, "streaming", False):
            # a streaming decoder's answer for the same audio improves as later phonemes
            # arrive (a held vowel is emitted when it ends): always ask again
            hit = self.muaalem([x], [self._ref_out], sampling_rate=SR)[0].phonemes.text
        else:
            # identical audio decodes identically: evaluation runs share long prefixes
            key = hashlib.blake2b(x.tobytes(), digest_size=16).digest()
            hit = _DECODE_CACHE.get(key)
            if hit is None:
                hit = self.muaalem([x], [self._ref_out], sampling_rate=SR)[0].phonemes.text
                if len(_DECODE_CACHE) > 20000:
                    _DECODE_CACHE.clear()
                _DECODE_CACHE[key] = hit
        self.last_dec = hit  # what was heard most recently, shown when a word is flagged
        return hit

    def _word_at(self, pos: int) -> int:
        for i, (a, b) in enumerate(self.bounds):
            if pos < b:
                return i
        return len(self.words) - 1

    def _near_fit(self, dec: str):
        nw = len(self.words)
        r0 = self.bounds[max(0, min(self.next_word, nw - 1) - 2)][0]
        r1 = self.bounds[min(nw - 1, self.next_word + LOOKAHEAD_WORDS)][1]
        self.spill = 0
        # continuation bias: starting the fit past the current word costs extra; while in the
        # optional lead-in, starting anywhere up to the verse itself is free (it may be skipped)
        q = min(self.next_word, nw - 1)
        if self.wmap[q] < self.optional_n:
            q = min(self._first_word_of(self.optional_n), nw - 1)
        here = self.bounds[q][0] - r0
        bias = dict(ahead_of=here, ahead_lam=AHEAD_BIAS)
        if r1 == len(self.ref):
            # the verse end is in reach: the learner may already be into the next verse
            start, end, c, total, self.spill = fit_spill(dec, self.ref[r0:r1], **bias)
        else:
            start, end, c, total = fit(dec, self.ref[r0:r1], **bias)
        cost = np.zeros(len(self.ref), dtype=np.float32)
        cost[r0:r1] = c
        # where each ref position falls in dec, over the whole verse
        P = fit.last_P
        self._P = np.empty(len(self.ref) + 1, dtype=np.int32)
        self._P[:r0] = P[0]
        self._P[r0:r1 + 1] = P
        self._P[r1 + 1:] = len(dec)
        return start + r0, end + r0, cost, total

    @staticmethod
    def _assess(dec, ref, P, a, b, start, lenient=False):
        """(severe, slight, severe ratio) for ref word [a, b): its heard sounds are
        dec[P[lo]:P[b]]. A word wholly before the fit was skipped. `lenient`: the last
        sound trails off into a pause or the next verse, so it may be missing."""
        if b <= start:
            return b - a, 0, 1.0
        lo = max(a, start)  # only the part of the word the window still sees
        if b - lo < MIN_VISIBLE * (b - a):
            return 0, 0, 0.0  # only a sliver is left in the window: not enough to judge
        rs, hs = ref[lo:b], dec[P[lo]:P[b]]
        sev, sl = classify(rs, hs)
        if P[lo] <= 1 and sev:
            # the word starts at the very edge of the window, where the decoder tends to
            # clip the first sound: not reliable enough to call a clear error
            return 0, sl, 0.0
        if lenient and len(rs) > 1:
            sev2, sl2 = classify(rs[:-1], hs)
            if (sev2, sl2) < (sev, sl):
                sev, sl = sev2, sl2
        return sev, sl, sev / max(1, len(rs))

    def _kind(self, sev, sl, ratio):
        if sev >= 1 and ratio > self.threshold:
            return "error"      # clear error: red
        if sl >= SLIGHT_MIN:
            return "slight"     # tajweed detail: amber
        return "ok"

    def _emit(self, assess, t: float, alt=None) -> Event:
        """assess: (severe, slight, ratio) against the default pace; alt(style) gives the same
        for another valid pace.
        Any pace (default): the best-matching pace wins, so a correct hadr or tahqiq reading
          passes. Words with a variable madd are always checked at every pace, so the pace
          actually used is known (for the "mixed paces" note).
        One pace chosen (self.pace): that pace decides; a word that is right at another valid
          pace becomes a gentle amber note ("read at a different pace"), never red."""
        q = self.next_word
        rank = {"ok": 0, "slight": 1, "error": 2}
        got = {DEFAULT_STYLE: assess}

        def at(st):
            if st not in got:
                got[st] = alt(st) if alt is not None else None
            return got[st]

        def key(st):
            r = at(st)
            return None if r is None else (rank[self._kind(*r)], r[0], r[1])

        variable = bool(VARIABLE_MADD.search(self.words[q]))
        ev_style, offpace = DEFAULT_STYLE, False
        if self.pace in STYLES:
            ev_style = self.pace
            r = at(self.pace) or assess
            if self._kind(*r) != "ok":
                for st in STYLES:
                    if st != self.pace and key(st) and key(st)[0] == 0:
                        r, ev_style, offpace = (0, max(SLIGHT_MIN, r[1]), 0.0), st, True
                        break
            sev, sl, ratio = r
            kind = "slight" if offpace else self._kind(sev, sl, ratio)
        else:
            order = list(STYLES) if (rank[self._kind(*assess)] > 0 or variable) else [DEFAULT_STYLE]
            order.sort(key=lambda st: st != DEFAULT_STYLE)  # ties go to the default pace
            best = DEFAULT_STYLE
            for st in order:
                if key(st) is not None and key(st) < key(best):
                    best = st
            ev_style = best
            sev, sl, ratio = at(best)
            kind = self._kind(sev, sl, ratio)
        ev = Event(kind, q, self.words[q], round(ratio, 2), t, self.wmap[q])
        ev.style, ev.slight, ev.offpace = ev_style, sl, offpace
        ev.variable = variable
        return ev

    def _style_ref(self, style, cuts, stop=None):
        words, _ = self._build(cuts, stop=stop, style=style)
        bounds, k = [], 0
        for w in words:
            bounds.append((k, k + len(w)))
            k += len(w)
        return words, "".join(words), bounds

    def _alt_stream(self, dec: str, q: int, final: bool, cuts=None):
        """Assessment of phoneme word q against another pace's reference (and, given
        `cuts`, other fresh starts), with the same alignment rules as the default."""
        cuts = self.cuts if cuts is None else cuts
        n_words = len(self._build(cuts)[0])

        def run(style):
            words, ref, bounds = self._style_ref(style, cuts)
            if len(words) != n_words:
                return None
            nw = len(words)
            r0 = bounds[max(0, min(q, nw - 1) - 2)][0]
            r1 = bounds[min(nw - 1, q + LOOKAHEAD_WORDS)][1]
            spill = 0
            bias = dict(ahead_of=bounds[q][0] - r0, ahead_lam=AHEAD_BIAS)
            if r1 == len(ref):
                s, e, _, _, spill = fit_spill(dec, ref[r0:r1], **bias)
            else:
                s, e, _, _ = fit(dec, ref[r0:r1], **bias)
            P = np.empty(len(ref) + 1, dtype=np.int32)
            P[:r0], P[r0:r1 + 1], P[r1 + 1:] = fit.last_P[0], fit.last_P, len(dec)
            s, e = s + r0, e + r0
            a, b = bounds[q]
            lenient = (final or (spill >= SPILL_MIN and e == len(ref))) and b == len(ref)
            return self._assess(dec, ref, P, a, b, s, lenient)
        return run

    def _alt_prefix(self, dec: str, q: int, cuts, stop_word: int):
        """Like _alt_stream for the settle-at-a-pause case: anchored to the stop."""
        def run(style):
            words, ref, bounds = self._style_ref(style, cuts, stop_word)
            if len(words) != len(self._build(cuts, stop=stop_word)[0]) or q >= len(words):
                return None
            s, _, _, _ = fit(dec, ref, anchor_end=True)
            a, b = bounds[q]
            return self._assess(dec, ref, fit.last_P, a, b, s, lenient=(b == len(ref)))
        return run

    def _other_boundary(self, dec: str, q: int, final: bool):
        """Phoneme word q judged with the opposite choice at its end: stopped (waqf) if the
        reference joins it to the next word, joined (wasl) if it stops there. Whether the
        learner stopped is not always caught as a pause (a short stop, a breath), and the
        ending changes with it: ta marbuta -> h, tanween fath -> aa, tanween and final
        vowels -> sukun, an idgham or ikhfa into the next word undone. Returns (assessment,
        cuts, q in that reference) or None."""
        end = self.written_span(q)[-1] + 1  # the written word after phoneme word q
        if end >= len(self.uw):
            return None  # the verse end is always read as a stop
        if end in self.cuts:
            cuts = [c for c in self.cuts if c != end]  # read as joined
        else:
            # read as stopped: only with a short stop in the stretch being judged, since a
            # stop's ending (final vowel dropped) is also what a word cut off short sounds like
            recent = len(self.audio) - int(self.window * SR)
            if not (self._silent_run >= SHORT_STOP_SEC * SR or any(p > recent for p in self._short_stops)):
                return None
            cuts = self.cuts + [end]
        words, wmap = self._build(cuts)
        q2 = next((k for k, w in enumerate(wmap) if w == self.wmap[q]), None)
        if q2 is None:
            return None
        return self._alt_stream(dec, q2, final, cuts)(DEFAULT_STYLE), sorted(set(cuts)), q2

    # --- judging ------------------------------------------------------------------
    def _settle_pause(self, dec: str, t: float) -> list[Event]:
        """The learner just went silent. Find the written word they stopped after, by
        which stop form fits the audio best, re-split the reference there (so the next
        word is expected in its start form) and judge everything up to it. A word cut off
        mid-way is left for after the pause, expected again from its start."""
        if len(dec) < MIN_PHONEMES or self.next_word >= len(self.words):
            return []
        _, end, _, total = self._near_fit(dec)
        if total > MAX_FIT_COST * len(dec):
            return []
        w_end = self.wmap[self._word_at(max(end - 1, 0))]
        # the best stop form, against carrying on as if there was no stop at all (a dip in
        # loudness the detector took for a pause): only re-split if stopping fits better
        q_end = self._word_at(max(end - 1, 0))
        s0, _, c0, tot0 = fit(dec, self.ref[:self.bounds[q_end][1]], anchor_end=True)
        P0 = fit.last_P
        best = None
        hi = min(len(self.uw) - 1, w_end + 1)
        # (never an empty range: if the learner went back before the last cut, still try stops
        # from the cut itself)
        for i in range(min(max(self.cuts[-1], w_end - 1), hi), hi + 1):
            cuts = [c for c in self.cuts if c <= i] + [i + 1]
            prefix = "".join(self._build(cuts, stop=i + 1)[0])
            s, _, c, tot = fit(dec, prefix, anchor_end=True)
            if best is None or tot < best[0]:
                best = (tot, i, s, c, cuts, fit.last_P)
        if tot0 <= best[0]:
            # read straight through (a dip in loudness, not a stop): judge up to here
            # against the continuous form and keep the reference as it is
            tot, s, c, P = tot0, s0, c0, P0
            if tot > MAX_FIT_COST * len(dec):
                return []
            alt_cuts = list(self.cuts)
            alt_stop = self.wmap[q_end + 1] if q_end + 1 < len(self.wmap) else len(self.uw)
        else:
            tot, i, s, c, cuts, P = best
            if tot > MAX_FIT_COST * len(dec):
                # stopped mid-word: they will restart that word, so expect its start form
                self._set_cuts([x for x in self.cuts if x <= self.wmap[self.next_word]] + [self.wmap[self.next_word]])
                return []
            self._set_cuts([x for x in cuts if x < len(self.uw)])
            alt_cuts, alt_stop = list(self.cuts), i + 1
        stop = len(c)  # where the stop form of written word i ends in the new reference
        events = []
        while self.next_word < len(self.words) and self.bounds[self.next_word][1] <= stop:
            a, b = self.bounds[self.next_word]
            if b <= s and self.wmap[self.next_word] < self.optional_n:
                events.append(Event("skip", self.next_word, self.words[self.next_word], 0.0, t, self.wmap[self.next_word]))
                self.next_word += 1  # optional lead-in not said: fine
                continue
            # the last sound before a pause trails off: it may be missing
            assess = self._assess(dec, self.ref, P, a, b, s, lenient=(b == stop))
            ev = self._emit(assess, t, alt=self._alt_prefix(dec, self.next_word, alt_cuts, alt_stop))
            events.append(ev)
            self.next_word += 1
            if ev.kind == "error":
                return events
        if self.next_word == len(self.words):
            events.append(Event("done", self.next_word, "", 0.0, t))  # stopped at the verse end
        return events

    def _judge(self, mode: str = "stream", upto: int | None = None) -> list[Event]:
        """mode: "stream" (normal), "pause" (learner went silent), "final" (recording over)."""
        final = mode == "final"
        if self.next_word >= len(self.words):
            return []  # the verse is already finished: nothing more to judge (and no second "done")
        dec = self._decode(upto)
        t = (len(self.audio) if upto is None else upto) / SR
        if mode == "pause":
            return self._settle_pause(dec, t)
        events = []
        nw = len(self.words)
        if self._seg_fresh and len(dec) >= self.first_look_min:
            # first look after a pause: the learner may have gone back anywhere in the
            # verse. Search from the verse start, preferring the closest fit to here.
            here = self.bounds[min(self.next_word, nw - 1)][0]
            r1 = self.bounds[min(nw - 1, self.next_word + LOOKAHEAD_WORDS)][1]
            start, _, _, total = fit(dec, self.ref[:r1], prefer=here, lam=POSITION_BIAS,
                                     ahead_of=here, ahead_lam=AHEAD_BIAS)
            if total <= MAX_FIT_COST * len(dec):
                self._seg_fresh = False
                # verses repeat phrases: only go back when the earlier place fits clearly
                # better than simply carrying on from here
                _, _, _, near_total = self._near_fit(dec)
                if self.resync:
                    # the learner carried on after a flag: pick up wherever they are now
                    self.resync = False
                    n_start, _, _, _ = self._near_fit(dec)
                    to = self.wmap[self._word_at(n_start)]
                    if to != self.wmap[min(self.next_word, nw - 1)]:
                        self._set_cuts([c for c in self.cuts if c < to] + [to])
                        self.next_word = self._first_word_of(to)
                        events.append(Event("back", self.next_word, self.words[self.next_word], 0.0, t, to))
                elif start < here - self.margin and total + BACK_MARGIN < near_total:
                    # resumed from an earlier word: expect its start form, re-check from there
                    back_to = self.wmap[self._word_at(start)]
                    self._set_cuts([c for c in self.cuts if c < back_to] + [back_to])
                    self.next_word = self._first_word_of(back_to)
                    events.append(Event("back", self.next_word, self.words[self.next_word], 0.0, t, back_to))
        start, end, cost, total = self._near_fit(dec)
        if not final and (len(dec) < MIN_PHONEMES or total > MAX_FIT_COST * max(1, len(dec) - self.spill)):
            return events  # too little or too garbled to place yet: wait for more audio
        # the verse's last sound may blend into the next verse, or trail off at the end
        end_lenient = final or (self.spill >= SPILL_MIN and end == len(self.ref))
        while self.next_word < len(self.words):
            a, b = self.bounds[self.next_word]
            passed = (end >= b + self.margin or (final and end > a)
                      or (b == len(self.ref) and end == b and self.spill >= SPILL_MIN))  # into the next verse
            if not passed:
                break
            if b <= start and self.wmap[self.next_word] < self.optional_n:
                # optional lead-in (isti'adha / basmala) not said: go on into the verse, no flag
                events.append(Event("skip", self.next_word, self.words[self.next_word], 0.0, t, self.wmap[self.next_word]))
                self.next_word += 1
                continue
            # (sounds never reached by the end of a recording count as missing: their
            # positions all map past the end of dec, so classify sees them as deleted)
            assess = self._assess(dec, self.ref, self._P, a, b, start,
                                  lenient=end_lenient and b == len(self.ref))
            ev = self._emit(assess, t, alt=self._alt_stream(dec, self.next_word, final))
            if ev.kind == "error":
                other = self._other_boundary(dec, self.next_word, final)
                if other and other[0] and self._kind(*other[0]) != "error":
                    # it was right with the other ending (stopped, or joined): take that
                    # reading, so the next word is expected in the matching form
                    self._set_cuts(other[1])
                    ev = self._emit(other[0], t, alt=self._alt_stream(dec, self.next_word, final))
                    events.append(ev)
                    self.next_word += 1
                    return events  # word positions changed: place the rest on the next update
            if ev.kind == "error" and not final and self._pending_red != self.next_word:
                # the window's edge often clips a word's last sounds: look again on the next
                # update, with the word well inside the window, before marking it red
                self._pending_red = self.next_word
                break
            self._pending_red = None
            events.append(ev)
            if ev.kind != "error" and self._repeated(dec, self.next_word):
                # said again straight away with no pause: a self-correction or restart,
                # not a mistake. Noted for a summary, never a stop.
                events.append(Event("repeat", ev.word, ev.text, 0.0, t, ev.wword))
            self.next_word += 1
            if ev.kind == "error":
                return events  # stop here: the learner is asked to repeat
        if final:
            # anything never reached was skipped or not recited
            for w in range(self.next_word, len(self.words)):
                events.append(Event("error", w, self.words[w], 1.0, t, self.wmap[w]))
            self.next_word = len(self.words)
        if self.next_word == len(self.words):
            events.append(Event("done", self.next_word, "", 0.0, t))
        return events

    def _repeated(self, dec: str, w: int) -> bool:
        """Word w (alone or ending a 2-3 word phrase) recited twice in a row.

        Only counts when the doubled phrase does not occur in the verse itself.
        """
        for span in (1, 2, 3):
            if w - span + 1 < 0:
                break
            phrase = "".join(self.words[w - span + 1: w + 1])
            if len(phrase) < MIN_REPEAT_PHONEMES:
                continue
            if phrase + phrase in dec and phrase + phrase not in self.ref:
                return True
        return False

    def feed(self, chunk: np.ndarray) -> list[Event]:
        if self.next_word >= len(self.words):
            return []
        events = []
        chunk = chunk.astype(np.float32)
        # pause detection: chunk energy against a slowly decaying speech level
        rms = float(np.sqrt(np.mean(chunk ** 2))) if len(chunk) else 0.0
        self._level = max(self._level * 0.995, rms)
        silent = rms < SILENCE_RATIO * self._level
        if silent:
            if self._silent_run == 0:
                self._pause_at = len(self.audio)
            self._silent_run += len(chunk)
            if self._spoke and not self._settled and self._silent_run >= SETTLE_SEC * SR:
                # quiet for a while (the verse may simply be finished): settle what was said
                # up to the pause now, rather than waiting for speech that may never come
                self._settled = True
                events += self._judge("pause", upto=self._pause_at)
                if any(e.kind in ("error", "done") for e in events):
                    return events
        else:
            if self._silent_run >= PAUSE_SEC * SR and self._spoke:
                # speech resumes after a pause: settle what was said before it (unless the
                # quiet already did), then start a new segment so the window never mixes the two
                if not self._settled:
                    events += self._judge("pause", upto=self._pause_at)
                self._seg_start = len(self.audio)
                self._seg_fresh = True
                self._since = 0
            if self._silent_run >= SHORT_STOP_SEC * SR:
                self._short_stops = [p for p in self._short_stops if p > len(self.audio) - 30 * SR] + [len(self.audio)]
            self._silent_run = 0
            self._settled = False
            self._spoke = True
        # store the chunk before any early return: it is the start of what comes next, and
        # whoever takes over (the next verse, or the tracker after a flag) is handed this audio
        self.audio = np.concatenate([self.audio, chunk])
        if any(e.kind in ("error", "done") for e in events):
            return events
        self._since += len(chunk)
        if self._since < self.hop * SR or silent:
            return events
        self._since = 0
        return events + self._judge("stream")

    def finish(self) -> list[Event]:
        if self.next_word >= len(self.words):
            return []
        return self._judge("final")


def run_file(muaalem, wave, sura, aya, chunk=0.1, **kw):
    """Simulate streaming a whole recording in `chunk`-second pieces."""
    streaming = getattr(muaalem, "streaming", False)
    if streaming:
        muaalem.reset()  # a fresh stream for this recording
    tr = VerseTracker(muaalem, sura, aya, **kw)
    n = int(chunk * SR)
    events = []
    for i in range(0, len(wave), n):
        if streaming:
            muaalem.push(wave[i:i + n])
        evs = tr.feed(wave[i:i + n])
        events += evs
        if any(e.kind == "error" for e in evs):
            return tr, events
    if streaming:
        muaalem.flush()  # the recording is over: let the last phonemes out
    events += tr.finish()
    return tr, events
