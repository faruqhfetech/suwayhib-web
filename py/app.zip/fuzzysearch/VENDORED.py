"""fuzzysearch 0.8.1 by Tal Einat (MIT licence), vendored: only its pure-Python modules.

On PyPI it ships as source with optional C speedups, which Chaquopy cannot build;
every C module has a pure-Python fallback, used here.
"""
