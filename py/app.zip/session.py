"""One learner's live session: find where they are reciting, then follow along.

Transport-agnostic: `feed(chunk)` takes 16 kHz float audio and returns messages (dicts)
for the interface. The web server and the offline test both drive it the same way.

States
  locating  - no verse known. Decode the recent speech, search the whole Qur'an; lock on
              when exactly one place matches (ambiguous openings wait for more audio).
  tracking  - a VerseTracker follows the current verse. When it finishes, the next verse
              starts automatically (and the page turns when needed). After a flagged
              word, the learner repeats from that word or anywhere before it. If nothing
              fits for a while, go back to locating (they moved somewhere else).
"""
import numpy as np
from quran_transcript import Aya, PhoneticSearch

from common import SR
from pages import AYAT, next_verse, page_content, page_of
from tracker import VerseTracker

LOCATE_MIN_SEC = 1.5    # speech needed before the first search
LOCATE_MAX_SEC = 8.0    # search window; older audio is dropped
LOCATE_EVERY_SEC = 0.5
LOST_AFTER_SEC = 5.0    # speech with no progress before re-finding (nearby only)
NEAR_AHEAD = 5          # after losing track, search up to this many verses ahead
STREAM_FIRST_LOOK = 12  # with a streaming decoder, phonemes before deciding the learner went back


class Session:
    lost_after = LOST_AFTER_SEC  # a streaming decoder that runs behind adds its delay here

    def __init__(self, muaalem):
        """muaalem: Muaalem itself, or a streaming decoder with the same call (see
        zipformer_decoder.py), which also hears every chunk (push) and runs a little behind."""
        self.m = muaalem
        if getattr(muaalem, "streaming", False):
            muaalem.reset()  # a fresh stream for this session
            # progress is only seen once decoded: allow for the decoder's delay before "lost"
            self.lost_after = Session.lost_after + (muaalem.hop + muaalem.ahead) / SR
        self.pace = None  # None = any valid pace; or one pace to practise
        self.search = PhoneticSearch()
        self._ref_dummy = None
        self.reset()

    def reset(self, keep_anchor: bool = False):
        """keep_anchor: lost track mid-session. Learners stay in the same surah (next
        verse, or a restart), so only search near where they were, never jump pages."""
        self.anchor = self.verse if keep_anchor and getattr(self, "verse", None) else None
        self.state = "locating"
        self.buf = np.zeros(0, dtype=np.float32)
        self.since = 0
        self.tracker = None
        self.verse = None       # (sura, aya)
        if not keep_anchor:
            self.page = None
        self.flagged = None     # (sura, aya, written word) just flagged
        self.cursor = None
        self.stalled = 0        # samples of speech since the tracker last moved
        self.candidates = []    # places an earlier, ambiguous stretch matched
        self.ambiguous = []     # places the current stretch matches, while ambiguous
        self.quiet = 0          # samples of silence in a row, while locating
        self.level = 0.0

    # --- helpers --------------------------------------------------------------------
    def _decode(self, x):
        if self._ref_dummy is None:
            from common import phonetize
            self._ref_dummy = phonetize(Aya(1, 1).get().uthmani)
        return self.m([x], [self._ref_dummy], sampling_rate=SR)[0].phonemes.text

    def _page_msgs(self, sura, aya):
        p = page_of(sura, aya)
        if p == self.page:
            return []
        self.page = p
        return [{"type": "page", **page_content(p)}]

    # --- verse 1's optional lead-in: isti'adha, then basmala --------------------------
    @staticmethod
    def _lead_in(sura, isti=True, basmala=True):
        """Words the learner may say before verse 1: the isti'adha (any surah) and the
        basmala (every surah but al-Fatiha, where it is verse 1 itself). At-Tawbah has no
        basmala: if one is said there, the learner gets a gentle note."""
        a = Aya(sura, 1).get()
        iw = a.istiaatha_uthmani.split() if isti else []
        bw = (a.bismillah_uthmani or Aya(2, 1).get().bismillah_uthmani).split() if basmala and sura != 1 else []
        return iw, bw

    def _tracker(self, sura, aya, start_word=0, resync=False, lead=None):
        """A VerseTracker; verse 1 gets the optional lead-in (lead = (isti words, basmala
        words)), with start_word counted over lead-in + verse words."""
        iw, bw = lead if lead is not None else (self._lead_in(sura) if aya == 1 else ([], []))
        tr = VerseTracker(self.m, sura, aya, start_word=start_word, resync=resync, prefix=iw + bw, pace=self.pace)
        if getattr(self.m, "streaming", False):
            tr.first_look_min = STREAM_FIRST_LOOK
        tr.n_isti, tr.n_basm = len(iw), len(bw)
        return tr

    def _out(self, w):
        """Tracker written-word index -> (aya, word) for the page, or None for the
        isti'adha (it has no line on the page). The basmala line is aya 0."""
        tr = self.tracker
        ni, nb = getattr(tr, "n_isti", 0), getattr(tr, "n_basm", 0)
        if w < ni:
            return None
        if w < ni + nb:
            return 0, w - ni
        return self.verse[1], w - ni - nb

    def _start_verse(self, sura, aya, word=0, carry=None, resync=False, lead=None):
        """carry: audio the previous verse's tracker heard past its end (the learner went
        straight on); the new tracker starts with it and syncs leniently. `word` counts the
        verse's own words; at verse 1 word 0 the optional lead-in comes first."""
        self.verse = (sura, aya)
        self.verse_paces = set()  # paces the variable madds of this verse were read at
        tr = self._tracker(sura, aya, resync=resync, lead=lead)
        lead_n = tr.n_isti + tr.n_basm
        if word:
            tr = self._tracker(sura, aya, start_word=lead_n + word, resync=resync, lead=lead)
        self.tracker = tr
        if carry is not None and len(carry):
            tr.audio = carry.astype(np.float32)
            tr._spoke = True
        self.state = "tracking"
        self.stalled = 0
        self.cursor = None
        loc = self._out(tr.wmap[min(tr.next_word, len(tr.wmap) - 1)]) or (aya, 0)
        return self._page_msgs(sura, aya) + [{"type": "verse", "sura": sura, "aya": aya,
                                              "word": loc[1] if loc[0] else 0, "basmala": loc[0] == 0}]

    def set_pace(self, pace):
        """'any', or one of the paces (hadr / tadwir / tahqiq) to practise."""
        from common import STYLES
        self.pace = pace if pace in STYLES else None
        if self.tracker is not None:
            self.tracker.pace = self.pace
        return [{"type": "pace", "pace": self.pace or "any"}]

    def start_at(self, sura: int, aya: int, word: int) -> list[dict]:
        if not (1 <= sura <= 114 and 0 <= aya <= AYAT[sura - 1]) or word < 0:
            return [{"type": "status", "text": "That place is not in the Qur'an."}]
        n = len(self._lead_in(sura, isti=False)[1]) if aya == 0 else len(Aya(sura, aya).get().uthmani_words)
        word = min(word, max(0, n - 1))
        return self._start_at(sura, aya, word)

    def _start_at(self, sura: int, aya: int, word: int) -> list[dict]:
        """The learner double-tapped a word: start (or resume) there. No locating needed,
        and later re-finding only searches near here. The word is expected in its start
        form; starting a word or two either side is still followed."""
        page = self.page
        self.reset()
        self.page = page_of(sura, max(1, aya)) if page is None else page
        if aya == 0:  # double-tapped the basmala line: start there (no isti'adha)
            self.anchor = (sura, 1)
            lead = ([], self._lead_in(sura, isti=False)[1])
            msgs = self._start_verse(sura, 1, 0, lead=lead)
            if word:
                self.tracker = self._tracker(sura, 1, start_word=word, lead=lead)
            return msgs + [{"type": "status", "text": f"Start from here: {sura}:1"}]
        self.anchor = (sura, aya)
        msgs = self._start_verse(sura, aya, word)
        return msgs + [{"type": "status", "text": f"Start from here: {sura}:{aya}"}]

    # --- locating -------------------------------------------------------------------
    def _search(self, ph):
        try:
            if not self.anchor:
                return self.search.search(ph)
            # near where they were: same surah, a verse back to a few ahead (the library's
            # own start/window arguments are not implemented yet, so filter here)
            s0, a0 = self.anchor
            res = self.search.search(ph, error_ratio=0.2)
            def near_here(r):  # same surah a verse back to a few ahead, or across a surah boundary
                s, a = r.end.sura_idx, r.end.aya_idx
                if s == s0:
                    return a0 - 1 <= a <= a0 + NEAR_AHEAD
                if s == s0 + 1:  # went on into the next surah (only from near this one's end)
                    return a <= NEAR_AHEAD and a0 >= AYAT[s0 - 1] - NEAR_AHEAD
                if s == s0 - 1:  # went back to the previous surah's end (only from near this one's start)
                    return a >= AYAT[s - 1] - 1 and a0 <= NEAR_AHEAD + 1
                return False

            def dist(r):
                s, a = r.end.sura_idx, r.end.aya_idx
                return abs(a - a0) if s == s0 else (a + AYAT[s0 - 1] - a0 if s > s0 else a0 + AYAT[s - 1] - a)
            near = [r for r in res if near_here(r)]
            near.sort(key=lambda r: (dist(r), -r.end.uthmani_word_idx))
            return near[:1]
        except Exception:  # NoPhonemesSearchResult: nothing within the error ratio
            return []

    def _locate(self):
        x = self.buf[-int(LOCATE_MAX_SEC * SR):]
        ph = self._decode(x)
        if len(ph) < 8:
            return [{"type": "status", "text": "Listening…"}]
        results = self._search(ph)
        if len(results) > 1 and self.candidates:
            # an earlier stretch matched several places (a shared refrain or opening):
            # keep the results that carry straight on from one of them
            follow = {next_verse(s, a) for s, a in self.candidates} | set(self.candidates)
            narrowed = [r for r in results if (r.start.sura_idx, r.start.aya_idx) in follow]
            if narrowed:
                results = narrowed
        if len(results) > 1:
            self.ambiguous = [(r.end.sura_idx, r.end.aya_idx) for r in results]
        if len(results) == 1:
            r = results[0]
            self.candidates = []
            msgs = [{"type": "status", "text": f"Found you: {r.end.sura_idx}:{r.end.aya_idx}"}]
            msgs += [{"type": "located", "sura": r.end.sura_idx, "aya": r.end.aya_idx,
                      "from_word": r.start.uthmani_word_idx if (r.start.sura_idx, r.start.aya_idx) ==
                      (r.end.sura_idx, r.end.aya_idx) else 0, "word": r.end.uthmani_word_idx}]
            # the matched words have already been said: follow from the word after them
            s, a, w = r.end.sura_idx, r.end.aya_idx, r.end.uthmani_word_idx + 1
            if w >= len(Aya(s, a).get().uthmani_words):
                nxt = next_verse(s, a)
                msgs += self._page_msgs(s, a)
                if nxt is None:
                    self.reset()
                    return msgs
                s, a, w = nxt[0], nxt[1], 0
            # the word being said right now is only partly in the match: hand the tracker
            # the last moments of audio and let it sync leniently, as at a verse handover
            msgs += self._start_verse(s, a, w, carry=self.buf[-int(1.5 * SR):], resync=True)
            self.buf = np.zeros(0, dtype=np.float32)
            return msgs
        if len(results) > 1:
            return [{"type": "status", "text": f"Matches {len(results)} places — keep going…"}]
        return [{"type": "status", "text": "Listening… (no match yet)"}]

    # --- tracking -------------------------------------------------------------------
    def _events_to_msgs(self, events):
        msgs = []
        s, a = self.verse
        tr = self.tracker
        for e in events:
            if e.kind in ("ok", "slight", "error"):
                loc = self._out(e.wword)
                if loc is None:  # isti'adha: followed, never shown or flagged
                    self.stalled = 0
                    continue
                if loc[0] == 0 and s == 9:
                    # at-Tawbah is recited without the basmala: a gentle note, once
                    if not getattr(tr, "tawbah_noted", False):
                        tr.tawbah_noted = True
                        msgs.append({"type": "note", "kind": "tawbah_basmala", "sura": 9, "aya": 1, "word": 0})
                    self.stalled = 0
                    continue
                span = [self._out(w) for w in tr.written_span(e.word)]
                m = {"type": "word", "status": e.kind, "sura": s, "aya": loc[0], "word": loc[1],
                     "words": [x[1] for x in span if x and x[0] == loc[0]], "err": round(e.err, 2),
                     "style": getattr(e, "style", ""), "slight": getattr(e, "slight", 0),
                     "missing": e.kind == "error" and e.err >= 0.99,  # skipped, not mispronounced
                     "offpace": getattr(e, "offpace", False)}  # right, but not at the pace being practised
                if getattr(e, "variable", False) and e.kind != "error" and not self.pace:
                    self.verse_paces.add(e.style)
                if e.kind in ("error", "slight"):
                    m.update(expected=self.tracker.uw[e.wword], expected_ph=e.text,
                             heard=getattr(self.tracker, "last_dec", ""))
                    if e.kind == "error":
                        self.flagged = (s, a, e.wword)
                msgs.append(m)
                self.stalled = 0
            elif e.kind == "back":
                loc = self._out(e.wword) or (a, 0)
                msgs.append({"type": "back", "sura": s, "aya": loc[0], "word": loc[1]})
                self.stalled = 0
            elif e.kind == "repeat":
                loc = self._out(e.wword)
                if loc:
                    msgs.append({"type": "note", "kind": "repeat", "sura": s, "aya": loc[0], "word": loc[1]})
            elif e.kind == "skip":
                self.stalled = 0  # optional lead-in not said: moving on into the verse
            elif e.kind == "done":
                if len(getattr(self, "verse_paces", ())) > 1:
                    # e.g. a munfasil at 2 counts and another at 4 in the same verse: valid
                    # readings each, but a teacher would ask for one pace throughout
                    msgs.append({"type": "note", "kind": "mixed_pace", "sura": s, "aya": a, "word": 0,
                                 "paces": sorted(self.verse_paces)})
                msgs.append({"type": "verse_done", "sura": s, "aya": a})
        return msgs

    def _after_events(self, msgs):
        """After a flag, keep following; after a verse ends, start the next one.

        A flag never stops the reading: the word is marked, and tracking carries on from
        the next word. If the learner goes back on their own to fix it, the tracker
        follows them back (it searches earlier in the verse after a pause) and re-checks."""
        if any(m["type"] == "word" and m["status"] == "error" for m in msgs):
            s, a, w = self.flagged
            self.flagged = None
            recent = self.tracker.audio[-int(1.5 * SR):]  # they are already saying the next word
            if w + 1 < len(self.tracker.uw):
                old = self.tracker
                ni, nb = getattr(old, "n_isti", 0), getattr(old, "n_basm", 0)
                lead = (old.uw[:ni], old.uw[ni:ni + nb])
                self.tracker = self._tracker(s, a, start_word=w + 1, resync=True, lead=lead)
                self.tracker.audio, self.tracker._spoke = recent.copy(), True
            else:
                nxt = next_verse(s, a)
                if nxt:
                    msgs += self._start_verse(*nxt, carry=recent, resync=True)
                else:
                    msgs += [{"type": "verse_done", "sura": s, "aya": a},
                             {"type": "status", "text": "End of the Qur'an. Ma shaa Allah!"}]
                    self.reset()
            return msgs
        if any(m["type"] == "verse_done" for m in msgs):
            nxt = next_verse(*self.verse)
            old = self.tracker
            carry = None
            if old is not None and (old.spill >= 3 or old._spoke):
                # went straight on: hand over the audio that already belongs to the next verse
                # the overflow plus ~1 s before it, so the new verse's first word is not at the
                # window's edge (where the first sound gets clipped); no forward jump follows
                n = int(min(2.5, 1.0 + 0.09 * old.spill) * SR)
                carry = old.audio[-n:]
            if nxt is None:
                msgs.append({"type": "status", "text": "End of the Qur'an. Ma shaa Allah!"})
                self.reset()
            else:
                # no forward jump at a handover: the learner is starting this verse, and a
                # phrase shared with a later part of it must not pull the tracker ahead
                msgs += self._start_verse(*nxt, carry=carry)
        return msgs

    def _cursor_msg(self):
        tr = self.tracker
        if tr is None or tr.next_word >= len(tr.words):
            return []
        w = tr.wmap[tr.next_word]
        if (self.verse, w) == self.cursor:
            return []
        self.cursor = (self.verse, w)
        loc = self._out(w)
        if loc is None or (loc[0] == 0 and self.verse[0] == 9):
            return []
        return [{"type": "cursor", "sura": self.verse[0], "aya": loc[0], "word": loc[1]}]

    # --- public ---------------------------------------------------------------------
    def feed(self, chunk: np.ndarray) -> list[dict]:
        chunk = np.nan_to_num(chunk.astype(np.float32))  # never let a bad sample poison decoding
        if getattr(self.m, "streaming", False):
            self.m.push(chunk)  # a streaming decoder hears everything, once, in order
        if self.state == "locating":
            rms = float(np.sqrt(np.mean(chunk ** 2))) if len(chunk) else 0.0
            self.level = max(self.level * 0.995, rms)
            if rms < 0.08 * self.level:
                self.quiet += len(chunk)
            else:
                if self.quiet >= 0.35 * SR and self.ambiguous:
                    # a pause after an ambiguous stretch: remember where it could have
                    # been and search the next stretch on its own
                    self.candidates = self.ambiguous
                    self.ambiguous = []
                    self.buf = np.zeros(0, dtype=np.float32)
                self.quiet = 0
            self.buf = np.concatenate([self.buf, chunk])[-int(LOCATE_MAX_SEC * SR):]
            self.since += len(chunk)
            if len(self.buf) < LOCATE_MIN_SEC * SR or self.since < LOCATE_EVERY_SEC * SR:
                return []
            self.since = 0
            return self._locate()
        before = (self.verse, self.tracker.next_word)
        msgs = self._events_to_msgs(self.tracker.feed(chunk))
        msgs = self._after_events(msgs)
        if self.state == "tracking":
            loud = float(np.sqrt(np.mean(chunk ** 2))) > 0.01
            if (self.verse, self.tracker.next_word) == before and loud:
                self.stalled += len(chunk)
            tr = self.tracker
            q = min(tr.next_word, len(tr.words) - 1)
            # a long (merged) phoneme word takes longer to say: allow for it
            if self.stalled > (self.lost_after + 0.12 * len(tr.words[q])) * SR:
                why = {"sura": self.verse[0], "aya": self.verse[1], "word": (self._out(tr.wmap[q]) or (0, 0))[1],
                       "expected_ph": tr.words[q], "heard": getattr(tr, "last_dec", "")}
                self.reset(keep_anchor=True)
                return msgs + [{"type": "lost", **why}, {"type": "status", "text": "Finding your place nearby…"}]
            msgs += self._cursor_msg()
        return msgs
