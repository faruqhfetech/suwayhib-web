"""The read-only data the front end asks for, independent of any web framework.

The web server (server.py) and the Android app both answer the page's requests with
these functions:
    /page/{n}  /verse/{s}/{a}  /surahs  /juz  /reciters  /timing/{s}/{a}?rec=
Each returns a JSON-ready object, or raises NotFound.
"""
import json
import re
from functools import lru_cache

from common import Aya

from common import REF_LIB
from pages import AYAT, NAMES_EN, juz_starts, page_content, page_of

LISTEN_RECITER = "Husary_64kbps"  # clear murattal reading for "Listen"


class NotFound(Exception):
    pass


def _int(v, lo, hi):
    try:
        v = int(v)
    except (TypeError, ValueError):
        raise NotFound()
    if not lo <= v <= hi:
        raise NotFound()
    return v


def reciter_ids():
    return sorted(p.stem for p in (REF_LIB / "timings").glob("*.json"))


@lru_cache(maxsize=8)
def _timings(rec):
    """quran-align word timings for one reciter: {(sura, aya): [[start_ms, end_ms] per written word]}."""
    out = {}
    with open(REF_LIB / "timings" / f"{rec}.json", encoding="utf-8") as f:
        entries = json.load(f)
    for e in entries:
        segs = e.get("segments") or []
        words = [None] * max((s[1] for s in segs), default=0)
        for w0, w1, t0, t1 in segs:
            for w in range(w0, w1):  # a segment can cover several written words
                words[w] = [t0, t1]
        out[(e["surah"], e["ayah"])] = words
    return out


def page(n):
    """All verses on one mushaf page (1-604)."""
    return page_content(_int(n, 1, 604))


def verse(s, a):
    """One verse's words and where it is, for the Practise section."""
    s = _int(s, 1, 114)
    a = _int(a, 1, AYAT[s - 1])
    v = Aya(s, a).get()
    return {"sura": s, "aya": a, "sura_name": v.sura_name, "words": v.uthmani_words,
            "ayat": AYAT[s - 1], "page": page_of(s, a)}


@lru_cache(maxsize=1)
def surahs():
    """The 114 surahs with their first page, for the picker."""
    return [{"sura": s, "name": Aya(s, 1).get().sura_name, "en": NAMES_EN[s - 1],
             "ayat": AYAT[s - 1], "page": page_of(s, 1)} for s in range(1, 115)]


def juz():
    """The 30 juz with where each starts, for the picker."""
    return [{"juz": i + 1, "sura": s, "aya": a, "page": page_of(s, a)} for i, (s, a) in enumerate(juz_starts())]


def reciters():
    """Reference reciters with word timings, for the Practise picker."""
    def name(r):  # "Abu_Bakr_Ash-Shaatree_128kbps" -> "Abu Bakr Ash-Shaatree"
        return re.sub(r"_(Murattal_)?\d+kbps$", "", r).replace("_", " ")
    return [{"id": r, "name": name(r)} for r in reciter_ids()]


def timing(s, a, rec=None):
    """Word timings of the reference recitation of one verse, for playing a single word."""
    s = _int(s, 1, 114)
    a = _int(a, 1, AYAT[s - 1])
    if rec not in reciter_ids():
        rec = LISTEN_RECITER
    return {"reciter": rec, "stem": f"{s:03d}{a:03d}", "words": _timings(rec).get((s, a), [])}


ROUTES = [  # (pattern, handler); query parameters are passed as keywords
    (re.compile(r"/page/([^/]+)"), page),
    (re.compile(r"/verse/([^/]+)/([^/]+)"), verse),
    (re.compile(r"/surahs"), surahs),
    (re.compile(r"/juz"), juz),
    (re.compile(r"/reciters"), reciters),
    (re.compile(r"/timing/([^/]+)/([^/]+)"), timing),
]


def handle(path, query=None):
    """Answer one request path, e.g. "/page/12" -> its JSON text. Raises NotFound."""
    for pat, fn in ROUTES:
        m = pat.fullmatch(path)
        if m:
            kw = {"rec": (query or {}).get("rec")} if fn is timing else {}
            return json.dumps(fn(*m.groups(), **kw), ensure_ascii=False)
    raise NotFound()
