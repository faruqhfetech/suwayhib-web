"""Minimal stand-in for pydantic, enough for quran_transcript on Android.

pydantic 2 needs pydantic-core (Rust), which has no Android build. quran_transcript only
declares two models (MoshafAttributes, SifaOutput) with defaults and one after-validator,
then reads attributes, so this covers: BaseModel with keyword construction, defaults
from Field(...), model_validator(mode="after") and model_fields. No type validation.
"""
from .fields import FieldInfo, PydanticUndefined

__all__ = ["BaseModel", "Field", "model_validator", "FieldInfo", "PydanticUndefined"]


def Field(default=PydanticUndefined, **kw):
    return FieldInfo(default=default, **kw)


def model_validator(mode="after"):
    def deco(fn):
        fn.__suwayhib_validator__ = mode
        return fn
    return deco


class BaseModel:
    model_fields: dict = {}

    def __init_subclass__(cls, **kw):
        super().__init_subclass__(**kw)
        fields = {}
        for base in reversed(cls.__mro__[1:]):
            fields.update(getattr(base, "model_fields", {}))
        for name, ann in getattr(cls, "__annotations__", {}).items():
            if name.startswith("_"):
                continue
            v = cls.__dict__.get(name, PydanticUndefined)
            info = v if isinstance(v, FieldInfo) else FieldInfo(default=v)
            info.annotation = ann
            fields[name] = info
            if isinstance(v, FieldInfo):
                delattr(cls, name)
        cls.model_fields = fields
        cls._validators = [f for b in reversed(cls.__mro__) for f in b.__dict__.values()
                           if getattr(f, "__suwayhib_validator__", None) == "after"]

    def __init__(self, **data):
        for name, info in self.model_fields.items():
            if name in data:
                value = data.pop(name)
            elif info.default is not PydanticUndefined:
                value = info.default
            elif info.default_factory is not None:
                value = info.default_factory()
            else:
                raise TypeError(f"{type(self).__name__}: missing field {name!r}")
            object.__setattr__(self, name, value)
        if data:
            raise TypeError(f"{type(self).__name__}: unknown fields {sorted(data)}")
        self.model_post_init(None)  # as pydantic: after fields are set, before validators
        for v in self._validators:
            v(self)

    def model_post_init(self, context):
        pass

    def model_dump(self):
        return {k: getattr(self, k) for k in self.model_fields}

    def __eq__(self, other):
        return type(other) is type(self) and self.model_dump() == other.model_dump()

    def __hash__(self):
        return hash(tuple(sorted(map(repr, self.model_dump().items()))))

    def __repr__(self):
        return f"{type(self).__name__}({', '.join(f'{k}={v!r}' for k, v in self.model_dump().items())})"
