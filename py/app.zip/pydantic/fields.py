"""FieldInfo and the 'no default' sentinel for the pydantic stand-in."""


class _Undefined:
    def __repr__(self):
        return "PydanticUndefined"


PydanticUndefined = _Undefined()


class FieldInfo:
    def __init__(self, default=PydanticUndefined, default_factory=None, description=None,
                 json_schema_extra=None, **kw):
        self.default = default
        self.default_factory = default_factory
        self.description = description if description is not None else PydanticUndefined
        self.json_schema_extra = json_schema_extra
        self.annotation = None
        self.extra = kw
