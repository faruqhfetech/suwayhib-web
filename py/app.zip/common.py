"""Paths, recitation paces, phonetizing and reference-audio loading shared by the app."""
import os
from functools import lru_cache
from pathlib import Path

from quran_transcript import MoshafAttributes, quran_phonetizer

SR = 16000
# server/data by default; SUWAYHIB_DATA points elsewhere (e.g. a shared disk)
DATA = Path(os.environ.get("SUWAYHIB_DATA", Path(__file__).resolve().parents[1] / "data"))
REF_LIB = DATA / "reference_library"   # 8 reciters, ayah-level audio, plus timings/ (word timings)
TESTSET = DATA / "testset"             # 2,000 labelled clips with deliberate errors (labels.jsonl)

# Valid recitation paces in Hafs differ in the variable madds (counts):
#   munfasil (word-final long vowel before a hamza), muttasil (before a hamza in the same
#   word, and at a stop), arid (before a stop). All three are correct readings.
STYLES = {
    "hadr":   MoshafAttributes(rewaya="hafs", madd_monfasel_len=2, madd_mottasel_len=4,
                               madd_mottasel_waqf=4, madd_aared_len=2),
    "tadwir": MoshafAttributes(rewaya="hafs", madd_monfasel_len=4, madd_mottasel_len=4,
                               madd_mottasel_waqf=4, madd_aared_len=4),
    "tahqiq": MoshafAttributes(rewaya="hafs", madd_monfasel_len=5, madd_mottasel_len=5,
                               madd_mottasel_waqf=5, madd_aared_len=6),
}
DEFAULT_STYLE = "tadwir"  # used for finding position; every style is accepted when scoring
MOSHAF = STYLES[DEFAULT_STYLE]


@lru_cache(maxsize=4096)
def phonetize(uthmani: str, remove_spaces: bool = True, style: str = DEFAULT_STYLE):
    """Cached: the tracker phonetizes the same verse pieces again at every verse handover
    and every re-split, and the phonetizer is slow (most of the phone's Python time).
    Callers only read the result."""
    return quran_phonetizer(uthmani, STYLES[style], remove_spaces=remove_spaces)


def ref_audio_path(sura: int, aya: int, reciter: str) -> Path:
    stem = f"{sura:03d}{aya:03d}"
    for ext in ("mp3", "wav"):  # Juz Amma ayahs are .wav
        p = REF_LIB / reciter / f"{stem}.{ext}"
        if p.exists():
            return p
    raise FileNotFoundError(stem)


def load_ref_audio(sura: int, aya: int, reciter: str):
    import librosa  # only for reference audio; not needed on the phone
    wav, _ = librosa.load(str(ref_audio_path(sura, aya, reciter)), sr=SR, mono=True)
    return wav


# quran-transcript's Aya reads and parses its whole Qur'an file (~10 MB of JSON) every time it is
# built unless it is handed the parsed data: a mushaf page took 0.15 s on a laptop, seconds on a
# phone. This Aya loads the file once and shares it.
_quran_dict = None


def Aya(sura_idx=1, aya_idx=1):
    global _quran_dict
    from quran_transcript import Aya as _Aya
    if _quran_dict is None:
        import json
        from quran_transcript.utils import BASE_PATH
        with open(BASE_PATH / "quran-script/quran-uthmani-imlaey.json", encoding="utf8") as f:
            _quran_dict = json.load(f)
    return _Aya(sura_idx, aya_idx, quran_dict=_quran_dict)
